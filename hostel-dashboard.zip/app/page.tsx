import { DashboardShell } from "@/components/dashboard-shell"
import { DashboardHeader } from "@/components/dashboard-header"
import { RecentActivity } from "@/components/recent-activity"
import { OccupancyStats } from "@/components/occupancy-stats"
import { RevenueChart } from "@/components/revenue-chart"

export default function DashboardPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Dashboard" description="Overview of your hostel management system." />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <OccupancyStats title="Total Rooms" value="120" description="8 vacant" trend="+2% from last month" />
        <OccupancyStats title="Occupancy Rate" value="93%" description="112 occupied" trend="+5% from last month" />
        <OccupancyStats title="Pending Maintenance" value="12" description="3 urgent" trend="-2 from last week" />
        <OccupancyStats title="Monthly Revenue" value="$28,650" description="April 2025" trend="+12% from last month" />
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <RevenueChart className="col-span-4" />
        <RecentActivity className="col-span-3" />
      </div>
    </DashboardShell>
  )
}
