"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/dashboard-shell"
import { DashboardHeader } from "@/components/dashboard-header"
import { RoomsTable } from "@/components/rooms-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { AddRoomForm } from "@/components/add-room-form"

export default function RoomsPage() {
  const [showAddForm, setShowAddForm] = useState(false)

  return (
    <DashboardShell>
      <DashboardHeader heading="Rooms Management" description="View and manage all rooms in your hostel.">
        <Button onClick={() => setShowAddForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Room
        </Button>
      </DashboardHeader>
      <RoomsTable />
      <AddRoomForm open={showAddForm} onOpenChange={setShowAddForm} />
    </DashboardShell>
  )
}
