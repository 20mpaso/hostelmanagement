"use client"

import { useState } from "react"
import { DashboardShell } from "@/components/dashboard-shell"
import { DashboardHeader } from "@/components/dashboard-header"
import { ResidentsTable } from "@/components/residents-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { AddResidentForm } from "@/components/add-resident-form"

export default function ResidentsPage() {
  const [showAddForm, setShowAddForm] = useState(false)

  return (
    <DashboardShell>
      <DashboardHeader heading="Residents Management" description="View and manage all residents in your hostel.">
        <Button onClick={() => setShowAddForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Resident
        </Button>
      </DashboardHeader>
      <ResidentsTable />
      <AddResidentForm open={showAddForm} onOpenChange={setShowAddForm} />
    </DashboardShell>
  )
}
