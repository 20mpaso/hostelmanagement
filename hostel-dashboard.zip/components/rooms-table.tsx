"use client"

import { useState } from "react"
import { Edit, MoreHorizontal, Trash } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Sample data for rooms
const roomsData = [
  {
    id: "R101",
    number: "101",
    type: "Single",
    floor: "1",
    capacity: 1,
    status: "Occupied",
    occupant: "John Doe",
    rate: "$550/month",
  },
  {
    id: "R102",
    number: "102",
    type: "Single",
    floor: "1",
    capacity: 1,
    status: "Vacant",
    occupant: "-",
    rate: "$550/month",
  },
  {
    id: "R103",
    number: "103",
    type: "Double",
    floor: "1",
    capacity: 2,
    status: "Occupied",
    occupant: "Emma Smith",
    rate: "$750/month",
  },
  {
    id: "R201",
    number: "201",
    type: "Double",
    floor: "2",
    capacity: 2,
    status: "Occupied",
    occupant: "Michael Brown",
    rate: "$750/month",
  },
  {
    id: "R202",
    number: "202",
    type: "Suite",
    floor: "2",
    capacity: 3,
    status: "Maintenance",
    occupant: "-",
    rate: "$950/month",
  },
  {
    id: "R203",
    number: "203",
    type: "Single",
    floor: "2",
    capacity: 1,
    status: "Reserved",
    occupant: "Sarah Johnson",
    rate: "$550/month",
  },
  {
    id: "R301",
    number: "301",
    type: "Suite",
    floor: "3",
    capacity: 3,
    status: "Vacant",
    occupant: "-",
    rate: "$950/month",
  },
  {
    id: "R302",
    number: "302",
    type: "Double",
    floor: "3",
    capacity: 2,
    status: "Occupied",
    occupant: "David Wilson",
    rate: "$750/month",
  },
]

export function RoomsTable() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("")

  const filteredRooms = roomsData.filter((room) => {
    const matchesSearch =
      room.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      room.occupant.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "" || room.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Occupied":
        return "blue"
      case "Vacant":
        return "green"
      case "Reserved":
        return "yellow"
      case "Maintenance":
        return "red"
      default:
        return "gray"
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <Input
          placeholder="Search rooms or occupants..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-xs"
        />
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="All Statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="Occupied">Occupied</SelectItem>
            <SelectItem value="Vacant">Vacant</SelectItem>
            <SelectItem value="Reserved">Reserved</SelectItem>
            <SelectItem value="Maintenance">Maintenance</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Room No.</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Floor</TableHead>
              <TableHead>Capacity</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Occupant</TableHead>
              <TableHead>Rate</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredRooms.map((room) => (
              <TableRow key={room.id}>
                <TableCell className="font-medium">{room.number}</TableCell>
                <TableCell>{room.type}</TableCell>
                <TableCell>{room.floor}</TableCell>
                <TableCell>{room.capacity}</TableCell>
                <TableCell>
                  <Badge
                    variant="outline"
                    className={`bg-${getStatusColor(room.status)}-100 text-${getStatusColor(room.status)}-800 border-${getStatusColor(room.status)}-200`}
                  >
                    {room.status}
                  </Badge>
                </TableCell>
                <TableCell>{room.occupant}</TableCell>
                <TableCell>{room.rate}</TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Edit className="mr-2 h-4 w-4" />
                        <span>Edit</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <span>View Details</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <span>Change Status</span>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>
                        <Trash className="mr-2 h-4 w-4" />
                        <span>Delete</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
