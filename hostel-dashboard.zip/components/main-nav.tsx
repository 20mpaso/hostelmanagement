import Link from "next/link"
import { Building } from "lucide-react"

export function MainNav() {
  return (
    <div className="flex items-center space-x-4">
      <Link href="/" className="flex items-center space-x-2">
        <Building className="h-6 w-6" />
        <span className="inline-block font-bold">Hostel Manager</span>
      </Link>
    </div>
  )
}
