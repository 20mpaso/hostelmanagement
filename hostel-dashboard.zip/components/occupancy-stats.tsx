import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface OccupancyStatsProps {
  title: string
  value: string
  description: string
  trend: string
  className?: string
}

export function OccupancyStats({ title, value, description, trend, className }: OccupancyStatsProps) {
  const isPositive = trend.includes("+")

  return (
    <Card className={className}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardContent>
      <CardFooter>
        <p className={`text-xs ${isPositive ? "text-green-500" : "text-red-500"}`}>{trend}</p>
      </CardFooter>
    </Card>
  )
}
