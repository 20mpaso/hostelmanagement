import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const activities = [
  {
    id: 1,
    user: "John Doe",
    action: "checked in",
    target: "Room 203",
    time: "2 hours ago",
    avatar: "JD",
  },
  {
    id: 2,
    user: "Emma Smith",
    action: "requested",
    target: "maintenance for Room 115",
    time: "4 hours ago",
    avatar: "ES",
  },
  {
    id: 3,
    user: "Michael Brown",
    action: "paid",
    target: "$650 for April rent",
    time: "5 hours ago",
    avatar: "MB",
  },
  {
    id: 4,
    user: "Sarah Johnson",
    action: "extended stay",
    target: "until June 15",
    time: "yesterday",
    avatar: "SJ",
  },
  {
    id: 5,
    user: "David Wilson",
    action: "checked out",
    target: "from Room 318",
    time: "yesterday",
    avatar: "DW",
  },
]

interface RecentActivityProps {
  className?: string
}

export function RecentActivity({ className }: RecentActivityProps) {
  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
        <CardDescription>Latest actions in your hostel</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-center">
              <Avatar className="h-9 w-9 mr-3">
                <AvatarImage src={`/placeholder.svg?height=36&width=36`} alt={activity.user} />
                <AvatarFallback>{activity.avatar}</AvatarFallback>
              </Avatar>
              <div className="space-y-1">
                <p className="text-sm font-medium leading-none">
                  {activity.user} <span className="text-muted-foreground">{activity.action}</span> {activity.target}
                </p>
                <p className="text-sm text-muted-foreground">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
