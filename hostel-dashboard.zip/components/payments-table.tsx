"use client"

import { useState } from "react"
import { MoreHorizontal, Receipt } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Sample data for payments
const paymentsData = [
  {
    id: "P001",
    resident: "John Doe",
    room: "101",
    amount: "$550",
    date: "2025-04-01",
    dueDate: "2025-04-05",
    paymentMethod: "Credit Card",
    status: "Paid",
    type: "Rent",
  },
  {
    id: "P002",
    resident: "Emma Smith",
    room: "103",
    amount: "$750",
    date: "-",
    dueDate: "2025-04-05",
    paymentMethod: "-",
    status: "Pending",
    type: "Rent",
  },
  {
    id: "P003",
    resident: "Michael Brown",
    room: "201",
    amount: "$750",
    date: "2025-04-02",
    dueDate: "2025-04-05",
    paymentMethod: "Bank Transfer",
    status: "Paid",
    type: "Rent",
  },
  {
    id: "P004",
    resident: "Sarah Johnson",
    room: "Reserved - 203",
    amount: "$275",
    date: "2025-03-15",
    dueDate: "-",
    paymentMethod: "PayPal",
    status: "Paid",
    type: "Deposit",
  },
  {
    id: "P005",
    resident: "David Wilson",
    room: "302",
    amount: "$750",
    date: "2025-04-03",
    dueDate: "2025-04-05",
    paymentMethod: "Cash",
    status: "Paid",
    type: "Rent",
  },
  {
    id: "P006",
    resident: "Jessica Taylor",
    room: "Previously 205",
    amount: "$150",
    date: "2025-03-01",
    dueDate: "-",
    paymentMethod: "Credit Card",
    status: "Paid",
    type: "Maintenance Fee",
  },
]

export function PaymentsTable() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("")
  const [typeFilter, setTypeFilter] = useState("")

  const filteredPayments = paymentsData.filter((payment) => {
    const matchesSearch =
      payment.resident.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.room.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "" || payment.status === statusFilter
    const matchesType = typeFilter === "" || payment.type === typeFilter
    return matchesSearch && matchesStatus && matchesType
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Paid":
        return "green"
      case "Pending":
        return "yellow"
      case "Overdue":
        return "red"
      default:
        return "gray"
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <Input
          placeholder="Search residents or rooms..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-xs"
        />
        <div className="flex gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="All Statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="Paid">Paid</SelectItem>
              <SelectItem value="Pending">Pending</SelectItem>
              <SelectItem value="Overdue">Overdue</SelectItem>
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="Rent">Rent</SelectItem>
              <SelectItem value="Deposit">Deposit</SelectItem>
              <SelectItem value="Maintenance Fee">Maintenance Fee</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Resident</TableHead>
              <TableHead>Room</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Payment Date</TableHead>
              <TableHead>Due Date</TableHead>
              <TableHead>Payment Method</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredPayments.map((payment) => (
              <TableRow key={payment.id}>
                <TableCell className="font-medium">{payment.resident}</TableCell>
                <TableCell>{payment.room}</TableCell>
                <TableCell>{payment.amount}</TableCell>
                <TableCell>{payment.date}</TableCell>
                <TableCell>{payment.dueDate}</TableCell>
                <TableCell>{payment.paymentMethod}</TableCell>
                <TableCell>{payment.type}</TableCell>
                <TableCell>
                  <Badge
                    variant="outline"
                    className={`bg-${getStatusColor(payment.status)}-100 text-${getStatusColor(payment.status)}-800 border-${getStatusColor(payment.status)}-200`}
                  >
                    {payment.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Receipt className="mr-2 h-4 w-4" />
                        <span>View Receipt</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <span>Send Reminder</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <span>Mark as Paid</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
