import type React from "react"
import { SidebarNav } from "@/components/sidebar-nav"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"

interface DashboardShellProps {
  children: React.ReactNode
}

export function DashboardShell({ children }: DashboardShellProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 border-b bg-background">
        <div className="flex h-16 items-center justify-between px-4">
          <MainNav />
          <UserNav />
        </div>
      </header>
      <div className="flex flex-1">
        <SidebarNav />
        <main className="flex-1 p-6 lg:p-8">
          <div className="mx-auto space-y-6">{children}</div>
        </main>
      </div>
    </div>
  )
}
