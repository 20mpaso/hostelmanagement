"use client"

import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const data = [
  { name: "Jan", revenue: 18500 },
  { name: "Feb", revenue: 22350 },
  { name: "Mar", revenue: 25600 },
  { name: "Apr", revenue: 28650 },
  { name: "May", revenue: 26700 },
  { name: "Jun", revenue: 29800 },
]

interface RevenueChartProps {
  className?: string
}

export function RevenueChart({ className }: RevenueChartProps) {
  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>Revenue Over Time</CardTitle>
        <CardDescription>Monthly revenue for the current year</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip formatter={(value: number) => [`$${value}`, "Revenue"]} />
            <Bar dataKey="revenue" fill="#3498db" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
