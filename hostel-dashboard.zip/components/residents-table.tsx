"use client"

import { useState } from "react"
import { Edit, MoreHorizontal, Trash } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

// Sample data for residents
const residentsData = [
  {
    id: "R001",
    name: "John Doe",
    email: "john.doe@example.com",
    phone: "+1 (555) 123-4567",
    room: "101",
    checkIn: "2025-01-15",
    checkOut: "2025-06-15",
    status: "Active",
    paymentStatus: "Paid",
    avatar: "JD",
  },
  {
    id: "R002",
    name: "Emma Smith",
    email: "emma.smith@example.com",
    phone: "+1 (555) 234-5678",
    room: "103",
    checkIn: "2025-02-01",
    checkOut: "2025-08-01",
    status: "Active",
    paymentStatus: "Pending",
    avatar: "ES",
  },
  {
    id: "R003",
    name: "Michael Brown",
    email: "michael.brown@example.com",
    phone: "+1 (555) 345-6789",
    room: "201",
    checkIn: "2025-01-05",
    checkOut: "2025-07-05",
    status: "Active",
    paymentStatus: "Paid",
    avatar: "MB",
  },
  {
    id: "R004",
    name: "Sarah Johnson",
    email: "sarah.johnson@example.com",
    phone: "+1 (555) 456-7890",
    room: "Reserved - 203",
    checkIn: "2025-05-01",
    checkOut: "2025-11-01",
    status: "Reserved",
    paymentStatus: "Deposit Paid",
    avatar: "SJ",
  },
  {
    id: "R005",
    name: "David Wilson",
    email: "david.wilson@example.com",
    phone: "+1 (555) 567-8901",
    room: "302",
    checkIn: "2025-03-10",
    checkOut: "2025-09-10",
    status: "Active",
    paymentStatus: "Paid",
    avatar: "DW",
  },
  {
    id: "R006",
    name: "Jessica Taylor",
    email: "jessica.taylor@example.com",
    phone: "+1 (555) 678-9012",
    room: "Previously 205",
    checkIn: "2024-09-01",
    checkOut: "2025-03-01",
    status: "Checked Out",
    paymentStatus: "Paid",
    avatar: "JT",
  },
]

export function ResidentsTable() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredResidents = residentsData.filter(
    (resident) =>
      resident.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resident.room.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resident.email.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "green"
      case "Reserved":
        return "yellow"
      case "Checked Out":
        return "gray"
      default:
        return "gray"
    }
  }

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "Paid":
        return "green"
      case "Pending":
        return "yellow"
      case "Deposit Paid":
        return "blue"
      case "Overdue":
        return "red"
      default:
        return "gray"
    }
  }

  return (
    <div className="space-y-4">
      <Input
        placeholder="Search residents, rooms, or emails..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="max-w-xs"
      />

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Resident</TableHead>
              <TableHead>Room</TableHead>
              <TableHead>Check In</TableHead>
              <TableHead>Check Out</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Payment</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredResidents.map((resident) => (
              <TableRow key={resident.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-9 w-9">
                      <AvatarImage src={`/placeholder.svg?height=36&width=36`} alt={resident.name} />
                      <AvatarFallback>{resident.avatar}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{resident.name}</div>
                      <div className="text-sm text-muted-foreground">{resident.email}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>{resident.room}</TableCell>
                <TableCell>{resident.checkIn}</TableCell>
                <TableCell>{resident.checkOut}</TableCell>
                <TableCell>
                  <Badge
                    variant="outline"
                    className={`bg-${getStatusColor(resident.status)}-100 text-${getStatusColor(resident.status)}-800 border-${getStatusColor(resident.status)}-200`}
                  >
                    {resident.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge
                    variant="outline"
                    className={`bg-${getPaymentStatusColor(resident.paymentStatus)}-100 text-${getPaymentStatusColor(resident.paymentStatus)}-800 border-${getPaymentStatusColor(resident.paymentStatus)}-200`}
                  >
                    {resident.paymentStatus}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Edit className="mr-2 h-4 w-4" />
                        <span>Edit</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <span>View Details</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <span>Change Status</span>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>
                        <Trash className="mr-2 h-4 w-4" />
                        <span>Delete</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
